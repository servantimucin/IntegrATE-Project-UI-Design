// Optional: if you need to extend Jest-like matchers for testing-library
import "@testing-library/jest-dom/vitest"
